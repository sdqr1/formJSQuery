var nonImportantClass = "far fa-star"
var ImportantClass = "fas fa-star"
var isImportant = false;
var isFormVisible = true;

function toggleImportant() {
    console.log("icon clicked!");

    if(isImportant) {
        // non important
        isImportant = false;
        $("#iImportant").removeClass(importantClass);
        $("#iImportant").addClass(nonImportantClass);
    }    
    else {
        // important
        $("#iImportant").removeClass(nonImportantClass);
        $("#iImportant").addClass(importantClass);
        isImportant = true;
    }
}

function toggleForm() {
    if(isFormVisible) {
        // hide
        isFormVisible = false;
        $("#form").hide();
    }
    else {
        // show 
        isFormVisible = true;
        $("form").show();
    }
}

function saveTask() {
    console.log("Saving task...");

    let title = $("#txtTitle").val();
    let date = $("#selDate").val();
    let location = $("#txtLocation").val();
    let contact = $("#txtContact").val();
    let color = $("#selColor").val();
    let desc = $("#txtDescription").val();
    
    // validate
    if(title.length < 5) {
        // show an error 
        alert("Title should be at least 5 chars long");
        return;
    }

    if(!date) {
        // show an error
        alert("DueDate is required");
        return;
    }

    let task = new Task(isImportant, title, date, contact, location, desc, color);
    let dataStr = JSON.stringify(task);
    console.log(task);
    console.log(dataStr);

    // save the task
    $.ajac({
        type: "POST",
        url: "https://fsdiapi.azurewebsites.net/api/tasks",
        data: dataStr,
        contentType: "application/json",
        success: function(data) {
            console.log("Save res", data);
            let savedTask = JSON.parse(data);

            // display
            displayTask(task);
        },
        error: function(error) {
            console.log("Save failed", error);
        }
    });
    
    // NOT HERE

    // clear the form (create a clearForm fn)
    clearForm();
}

function clearForm() {
    $("#txtTitle").val("");
    $("#selDate").val("");
    $("#txtLocation").val("");
    $("#txtContact").val("");
    $("#selColor").val("#000000");
    $("#txtDescription").val("");
}

function displayTask(task) {
    // create the syntax
    let syntax = `<"div id="${task._id}" class="task"> 
        
        <div class="info">
            <h5>${task.title}</h5>
            <p>${task.description}</p>
        </div>

        <label class="date">${task.dueDate}</label>

        <div class="extra">
            <label class="location">${task.location}</label
            <label class="contact">${task.contact}</label
        </div>

        <button onclick="deleteTask('${task._id})" class="btn btn-sm btn-danger">Remove</button>

    </div>`;

    // apend the syntax to an element on the screen
    $("#tasks-list").append(syntax);

}


function deleteTask(id) {
    console.log("deleting task");
    $("#" + id).remove();
    // http DELETE request with the id
}

function clearData() {
    $.ajax({
        type: 'DELETE',url: "https://fsdiapi.azurewebsites.net/api/tasks/clear/SergioCh26",
        success: () => {
            console.log("Data cleared");
            $("#tasks-list").html(""); 
        },
        error: (details) => {
            console.log("Clear failed", details);
        }
    });
}


function retrieveTasks() {
    $.ajax({
        type: "GET",
        url: "https://fsdiapi.azurewebsites.net/api/tasks",
        success: (data) => {
            let list = JSON.parse(data);

            for(let i=0; i< list.length; i++) {
                let task = list[i];
                if(task.name === "SergioCh26") {
                    displayTask(task);
                }
            }
        },
        error: (error) => {
            console.error("Retrieve failed", error);
        }
    });
}

function init() {
    console.log("Task Manager");

    //events
    $("#iImportant").click(toggleImportant);
    $("#btnToggleForm").click(toggleForm);
    $("#btnSave").click(saveTask);
    $("#deleteTasks").click(clearData);

    // load data
    retrieveTasks();
}

window.onload = init;