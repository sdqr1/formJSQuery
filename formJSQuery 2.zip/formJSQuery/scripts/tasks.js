
class Task {

    constructor(important, title, dueDate, contact, location, desc, color) {
        this.important = important;
        this.color = color;
        this.dueDate = dueDate;
        this.title = title;
        this.location = location;
        this.contact = contact;
        this.description = desc;

        this.name = "SergioCh26";
    }
    
}