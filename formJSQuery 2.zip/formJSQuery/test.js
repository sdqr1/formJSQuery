




function testRequest() {
    // https://restclass.azurewebsites.net/api/test
    
}

// exec the fn 
objects();

testRequest();