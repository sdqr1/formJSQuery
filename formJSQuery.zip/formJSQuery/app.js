var nonImportantClass = "far fa-star"
var ImportantClass = "fas fa-star"
var isImportant = false;
var isFormVisible = true;

function toggleImportant() {
    console.log("icon clicked!");

    if(isImportant) {
        // non important
        isImportant = false;
        $("#iImportant").removeClass(importantClass);
        $("#iImportant").addClass(nonImportantClass);
    
    }    
    else {
        // important
        $("#iImportant").removeClass(nonImportantClass);
        $("#iImportant").addClass(importantClass);
        isImportant = true;
    }
}

function toggleForm() {
    if(isFormVisible) {
        // hide
        isFormVisible = false;
        $("#form").hide();
    }
    else {
        // show 
        isFormVisible = true;
        $("form").show();
    }
}

function saveTask() {
    console.log("Saving task...");

    let title = $("#txtTitle").val();
    let date = $("#selDate").val();
    let location = $("#txtLocation").val();
    let contact = $("#txtContact").val();
    let color = $("#selColor").val();
    let desc = $("#txtDescription").val();
    
    // validate
    if(title.length < 5) {
        // show an error 
        alert("Title should be at least 5 chars long");
        return;
    }

    if(!date) {
        // show an error
        alert("DueDate is required");
        return;
    }

    let task = new Task(isImportant, title, date, contact, location, desc, color);
    console.log(task);

    // save the task

    // display
    displayTask(task);

    // clear the form (create a clearForm fn)
    clearForm();

function clearForm() {
    // create the syntax
    let syntax = `<"div class="task">
        
        <div class="info">
            <h5>${task.title}</h5>
            <p>${task.description}</p>
        </div>

        <label class="date">${task.dueDate}</label>

        <div class="extra">
            <label class="location">${task.location}</label
            <label class="contact">${task.contact}</label
        </div>

        <button onclick="deleteTask()" class="btn btn-sm btn-danger">Remove</button>

    </div>`;

    // apend the syntax to an element on the screen
    $("#tasks-list").append(syntax);

    }
}

function deleteTask() {
    console.log("deleting task");
}


function init() {
    console.log("Task Manager");

    //events
    $("#iImportant").click(toggleImportant);
    $("#btnToggleForm").click(toggleForm);
    $("#btnSave").click(saveTask);


    // load data
}

window.onload = init;